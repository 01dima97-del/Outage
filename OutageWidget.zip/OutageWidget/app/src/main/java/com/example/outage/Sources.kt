package com.example.outage

import android.content.Context

object Sources {
    fun refresh(ctx: Context) {
        if (Schedule.source(ctx) == "mykolaiv") Mykolaiv.refresh(ctx) else Yasno.refresh(ctx)
    }

    fun refreshIfStale(ctx: Context): Boolean {
        val now = System.currentTimeMillis()
        if (now - Schedule.fetchedAt(ctx) < 10 * 60_000L) return false
        if (now - Schedule.getLong(ctx, "y_try") < 3 * 60_000L) return false
        Schedule.putLong(ctx, "y_try", now)
        refresh(ctx)
        return true
    }
}
