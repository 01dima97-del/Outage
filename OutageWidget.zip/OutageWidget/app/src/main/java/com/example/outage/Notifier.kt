package com.example.outage

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.media.AudioAttributes
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

object Notifier {
    private const val CHANNEL = "schedule_changes_v2"
    private const val OLD_CHANNEL = "schedule_changes"
    private const val ID = 1001

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("outage", Context.MODE_PRIVATE)

    fun enabled(ctx: Context): Boolean = prefs(ctx).getBoolean("notify", true)

    fun setEnabled(ctx: Context, on: Boolean) {
        prefs(ctx).edit().putBoolean("notify", on).apply()
    }

    fun askedBefore(ctx: Context): Boolean = prefs(ctx).getBoolean("notify_asked", false)

    fun markAsked(ctx: Context) {
        prefs(ctx).edit().putBoolean("notify_asked", true).apply()
    }

    fun ensureChannel(ctx: Context) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.deleteNotificationChannel(OLD_CHANNEL)
        val sound = Uri.parse("android.resource://" + ctx.packageName + "/" + R.raw.light_change)
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_NOTIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        val channel = NotificationChannel(CHANNEL, "Зміни графіка", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Сповіщення про зміну графіка відключень світла"
            setSound(sound, attrs)
            enableVibration(true)
            vibrationPattern = longArrayOf(0, 120, 80, 220)
        }
        nm.createNotificationChannel(channel)
    }

    fun postTest(ctx: Context): Boolean =
        post(ctx, "Черга ${Schedule.group(ctx)}: тестове сповіщення", listOf("Так звучатимуть сповіщення про зміну графіка."))

    private class Rec(val published: Boolean, val slots: List<IntArray>, val maybe: List<IntArray>) {
        fun sig(): String =
            slots.joinToString(",") { "${it[0]}-${it[1]}" } + "|" + maybe.joinToString(",") { "${it[0]}-${it[1]}" }
    }

    private fun list(a: JSONArray?): List<IntArray> {
        val out = mutableListOf<IntArray>()
        if (a == null) return out
        for (i in 0 until a.length()) {
            val x = a.getJSONArray(i)
            out.add(intArrayOf(x.getInt(0), x.getInt(1)))
        }
        return out
    }

    private fun parse(json: String): Map<String, Rec> {
        val out = LinkedHashMap<String, Rec>()
        val days = JSONObject(json).getJSONArray("days")
        for (i in 0 until days.length()) {
            val d = days.getJSONObject(i)
            out[d.optString("date")] = Rec(
                d.optString("status") != "WaitingForSchedule",
                list(d.optJSONArray("slots")),
                list(d.optJSONArray("maybe"))
            )
        }
        return out
    }

    private fun describe(r: Rec): String {
        val base = if (r.slots.isEmpty()) "відключень немає" else Schedule.fmtList(r.slots)
        return if (r.maybe.isNotEmpty()) base + " · можливі: " + Schedule.fmtList(r.maybe) else base
    }

    fun check(ctx: Context, oldJson: String?, newJson: String) {
        if (oldJson == null || !enabled(ctx)) return
        val old = parse(oldJson)
        val fresh = parse(newJson)
        val today = LocalDate.now()
        val lines = mutableListOf<String>()
        var anyChanged = false

        val todayKey = today.toString()
        val tomorrowKey = today.plusDays(1).toString()

        val nToday = fresh[todayKey]
        val oToday = old[todayKey]
        if (nToday != null && nToday.published && oToday != null && oToday.published && oToday.sig() != nToday.sig()) {
            lines.add("Сьогодні: " + describe(nToday))
            anyChanged = true
        }

        val nTomorrow = fresh[tomorrowKey]
        val oTomorrow = old[tomorrowKey]
        if (nTomorrow != null && nTomorrow.published) {
            if (oTomorrow == null || !oTomorrow.published) {
                lines.add("Завтра (опубліковано): " + describe(nTomorrow))
            } else if (oTomorrow.sig() != nTomorrow.sig()) {
                lines.add("Завтра: " + describe(nTomorrow))
                anyChanged = true
            }
        }

        if (lines.isEmpty()) return
        val group = Schedule.group(ctx)
        val title = if (anyChanged) "Черга $group: графік змінено" else "Черга $group: опубліковано графік на завтра"
        post(ctx, title, lines)
    }

    private fun post(ctx: Context, title: String, lines: List<String>): Boolean {
        if (Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return false
        ensureChannel(ctx)
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val pi = PendingIntent.getActivity(
            ctx, 3, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle(title)
            .setContentText(lines.first())
            .setStyle(Notification.BigTextStyle().bigText(lines.joinToString("\n")))
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        nm.notify(ID, n)
        return true
    }
}
