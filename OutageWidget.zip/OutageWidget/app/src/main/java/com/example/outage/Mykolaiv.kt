package com.example.outage

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.ZoneId

object Mykolaiv {
    private const val BASE = "https://off.energy.mk.ua/api"

    private val fallback = mapOf(
        "1.1" to 14, "1.2" to 15, "2.1" to 16, "2.2" to 17, "3.1" to 19, "3.2" to 20,
        "4.1" to 21, "4.2" to 22, "5.1" to 24, "5.2" to 25, "6.1" to 26, "6.2" to 27
    )

    private fun queueId(ctx: Context, group: String): Int {
        val sp = ctx.getSharedPreferences("outage", Context.MODE_PRIVATE)
        var map: JSONObject? = null
        val cached = sp.getString("mk_queues", null)
        if (cached != null) {
            try { map = JSONObject(cached) } catch (e: Exception) { map = null }
        }
        if (map == null || !map.has(group)) {
            try {
                val arr = JSONArray(Yasno.get("$BASE/outage-queue/by-type/3"))
                val m = JSONObject()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    m.put(o.getString("name"), o.getInt("id"))
                }
                sp.edit().putString("mk_queues", m.toString()).apply()
                map = m
            } catch (e: Exception) {
                // залишаємо запасну відповідність
            }
        }
        if (map != null && map.has(group)) return map.getInt(group)
        return fallback[group] ?: error("Черги $group немає")
    }

    private fun toIntervals(b: BooleanArray): JSONArray {
        val out = JSONArray()
        var start = -1
        for (t in 1..49) {
            val on = t <= 48 && b[t]
            if (on && start < 0) start = t
            if (!on && start >= 0) {
                out.put(JSONArray().put((start - 1) * 30).put((t - 1) * 30))
                start = -1
            }
        }
        return out
    }

    fun refresh(ctx: Context) {
        try {
            val qid = queueId(ctx, Schedule.group(ctx))
            val arr = JSONArray(Yasno.get("$BASE/v2/schedule/active"))
            val zone = ZoneId.of("Europe/Kyiv")
            val days = JSONArray()
            for (i in 0 until arr.length()) {
                val sch = arr.getJSONObject(i)
                val date = Instant.parse(sch.getString("from")).atZone(zone).toLocalDate().toString()
                val definite = BooleanArray(49)
                val maybe = BooleanArray(49)
                val series = sch.getJSONArray("series")
                for (j in 0 until series.length()) {
                    val s = series.getJSONObject(j)
                    if (s.getInt("outage_queue_id") != qid) continue
                    val t = s.getInt("time_series_id")
                    if (t !in 1..48) continue
                    when (s.optString("type")) {
                        "OFF", "SURE_OFF" -> definite[t] = true
                        "PROBABLY_OFF" -> maybe[t] = true
                    }
                }
                for (t in 1..48) if (definite[t]) maybe[t] = false
                days.put(
                    JSONObject().put("date", date).put("status", "ScheduleApplies")
                        .put("slots", toIntervals(definite)).put("maybe", toIntervals(maybe))
                )
            }
            Schedule.saveData(ctx, JSONObject().put("days", days).toString(), "")
        } catch (e: Exception) {
            Schedule.setError(ctx, e.message ?: e.javaClass.simpleName)
        }
    }
}
