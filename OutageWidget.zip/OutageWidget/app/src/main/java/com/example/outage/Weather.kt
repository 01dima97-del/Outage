package com.example.outage

import android.content.Context
import android.location.Geocoder
import org.json.JSONObject
import java.net.URLEncoder
import java.util.Locale

class WeatherInfo(val temp: Int, val code: Int, val min: Int, val max: Int)

class City(val name: String, val admin: String, val lat: Double, val lon: Double) {
    fun label(): String = if (admin.isNotEmpty() && admin != name) "$name, $admin" else name
}

object Weather {
    private const val DEFAULT_LAT = 47.9105
    private const val DEFAULT_LON = 33.3918
    private const val DEFAULT_CITY = "Кривий Ріг"

    private fun p(ctx: Context) = ctx.getSharedPreferences("outage", Context.MODE_PRIVATE)

    fun cityName(ctx: Context): String = p(ctx).getString("w_city", DEFAULT_CITY) ?: DEFAULT_CITY
    fun mode(ctx: Context): String = p(ctx).getString("w_mode", "default") ?: "default"

    fun saveLocation(ctx: Context, lat: Double, lon: Double, city: String, mode: String) {
        p(ctx).edit()
            .putString("w_lat", lat.toString())
            .putString("w_lon", lon.toString())
            .putString("w_city", city)
            .putString("w_mode", mode)
            .putLong("w_fetched", 1L)
            .putLong("w_try", 0L)
            .apply()
    }

    private fun url(ctx: Context): String {
        val lat = p(ctx).getString("w_lat", null)?.toDoubleOrNull() ?: DEFAULT_LAT
        val lon = p(ctx).getString("w_lon", null)?.toDoubleOrNull() ?: DEFAULT_LON
        return "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
            "&current=temperature_2m,weather_code&daily=temperature_2m_max,temperature_2m_min" +
            "&timezone=auto&forecast_days=1"
    }

    fun cached(ctx: Context): WeatherInfo? {
        val sp = p(ctx)
        if (sp.getLong("w_fetched", 0L) == 0L) return null
        if (!sp.contains("w_temp")) return null
        return WeatherInfo(sp.getInt("w_temp", 0), sp.getInt("w_code", 0), sp.getInt("w_min", 0), sp.getInt("w_max", 0))
    }

    fun refreshIfStale(ctx: Context): Boolean {
        val now = System.currentTimeMillis()
        if (now - Schedule.getLong(ctx, "w_fetched") < 30 * 60_000L) return false
        if (now - Schedule.getLong(ctx, "w_try") < 5 * 60_000L) return false
        refresh(ctx)
        return true
    }

    fun refresh(ctx: Context) {
        Schedule.putLong(ctx, "w_try", System.currentTimeMillis())
        try {
            val root = JSONObject(Yasno.get(url(ctx)))
            val cur = root.getJSONObject("current")
            val daily = root.getJSONObject("daily")
            p(ctx).edit()
                .putInt("w_temp", Math.round(cur.getDouble("temperature_2m")).toInt())
                .putInt("w_code", cur.getInt("weather_code"))
                .putInt("w_max", Math.round(daily.getJSONArray("temperature_2m_max").getDouble(0)).toInt())
                .putInt("w_min", Math.round(daily.getJSONArray("temperature_2m_min").getDouble(0)).toInt())
                .putLong("w_fetched", System.currentTimeMillis())
                .apply()
        } catch (e: Exception) {
            // залишаємо попередні дані
        }
    }

    fun search(name: String): List<City> {
        val q = URLEncoder.encode(name, "UTF-8")
        val root = JSONObject(Yasno.get("https://geocoding-api.open-meteo.com/v1/search?name=$q&count=6&language=uk&format=json"))
        val arr = root.optJSONArray("results") ?: return emptyList()
        val out = mutableListOf<City>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out.add(City(o.getString("name"), o.optString("admin1", ""), o.getDouble("latitude"), o.getDouble("longitude")))
        }
        return out
    }

    @Suppress("DEPRECATION")
    fun reverseName(ctx: Context, lat: Double, lon: Double): String {
        try {
            val g = Geocoder(ctx, Locale("uk", "UA"))
            val a = g.getFromLocation(lat, lon, 1)
            if (!a.isNullOrEmpty()) {
                val ad = a[0]
                val n = ad.locality ?: ad.subAdminArea ?: ad.adminArea
                if (!n.isNullOrEmpty()) return n
            }
        } catch (e: Exception) {
            // пробуємо запасний варіант
        }
        try {
            val j = JSONObject(
                Yasno.get("https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=$lat&longitude=$lon&localityLanguage=uk")
            )
            val n = j.optString("city").ifEmpty { j.optString("locality") }
            if (n.isNotEmpty()) return n
        } catch (e: Exception) {
            // нічого
        }
        return "Моє місце"
    }

    fun describe(code: Int): Pair<String, String> = when (code) {
        0 -> "☀️" to "Ясно"
        1 -> "🌤️" to "Переважно ясно"
        2 -> "⛅" to "Мінлива хмарність"
        3 -> "☁️" to "Хмарно"
        45, 48 -> "🌫️" to "Туман"
        in 51..57 -> "🌦️" to "Мряка"
        in 61..67 -> "🌧️" to "Дощ"
        in 71..77 -> "🌨️" to "Сніг"
        in 80..82 -> "🌦️" to "Злива"
        85, 86 -> "🌨️" to "Снігопад"
        in 95..99 -> "⛈️" to "Гроза"
        else -> "☁️" to "Хмарно"
    }

    fun fmtTemp(t: Int): String = if (t > 0) "+$t°" else "$t°"
}
