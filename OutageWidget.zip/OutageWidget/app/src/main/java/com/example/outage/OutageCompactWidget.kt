package com.example.outage

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.os.Bundle

class OutageCompactWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val pending = goAsync()
        OutageWidget.runUpdate(context) { pending.finish() }
    }

    override fun onAppWidgetOptionsChanged(
        context: Context, manager: AppWidgetManager, appWidgetId: Int, newOptions: Bundle
    ) {
        super.onAppWidgetOptionsChanged(context, manager, appWidgetId, newOptions)
        Thread { OutageWidget.renderAll(context) }.start()
    }

    override fun onDisabled(context: Context) {
        OutageWidget.cancelTickIfNoWidgets(context)
    }
}
