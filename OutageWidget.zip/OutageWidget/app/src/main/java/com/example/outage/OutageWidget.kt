package com.example.outage

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.widget.RemoteViews
import java.util.Calendar

class OutageWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val pending = goAsync()
        Thread {
            try {
                Yasno.refresh(context)
                renderAll(context)
            } finally {
                pending.finish()
            }
        }.start()
    }

    companion object {
        fun renderAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, OutageWidget::class.java))
            if (ids.isNotEmpty()) render(context, manager, ids)
        }

        private fun render(context: Context, manager: AppWidgetManager, ids: IntArray) {
            val plan = Schedule.plan(context)
            val cal = Calendar.getInstance()
            val now = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)

            var status: String
            var sub: String
            var next: Int? = null

            if (!plan.hasData) {
                status = "Немає даних"
                sub = Schedule.error(context) ?: "Очікуємо графік"
            } else if (plan.emergency) {
                status = "Аварійні відключення"
                sub = "Графік тимчасово не діє"
            } else {
                val current = plan.intervals.firstOrNull { now >= it[0] && now < it[1] }
                if (current != null) {
                    status = "Зараз світла немає"
                    sub = "Увімкнення о ${Schedule.fmt(current[1])} (через ${Schedule.dur(current[1] - now)})"
                    next = current[1]
                } else {
                    status = "Зараз світло є"
                    val up = plan.intervals.firstOrNull { it[0] > now }
                    sub = if (up != null)
                        "Відключення о ${Schedule.fmt(up[0])} (через ${Schedule.dur(up[0] - now)})"
                    else "Відключень більше немає"
                    next = up?.get(0)
                }
            }

            var list = if (plan.hasData) Schedule.todayText(plan).ifEmpty { "Сьогодні без відключень" } else ""
            if (plan.waiting) list += "\nГрафік може змінитися"
            val fetched = Schedule.fetchedAt(context)
            if (fetched > 0) {
                val t = Calendar.getInstance().apply { timeInMillis = fetched }
                val stamp = "%02d:%02d".format(t.get(Calendar.HOUR_OF_DAY), t.get(Calendar.MINUTE))
                list += if (Schedule.error(context) != null) "\nНемає зв'язку, дані від $stamp" else "\nОновлено $stamp"
            }

            val openApp = PendingIntent.getActivity(
                context, 0, Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            for (id in ids) {
                val views = RemoteViews(context.packageName, R.layout.widget)
                views.setTextViewText(R.id.title, "Кривий Ріг · черга ${Schedule.group(context)}")
                views.setTextViewText(R.id.status, status)
                views.setTextViewText(R.id.sub, sub)
                views.setTextViewText(R.id.list, list.trim())
                views.setImageViewBitmap(R.id.bar, bar(plan.intervals, now))
                views.setOnClickPendingIntent(R.id.root, openApp)
                manager.updateAppWidget(id, views)
            }
            scheduleNext(context, ids, next, now)
        }

        private fun scheduleNext(context: Context, ids: IntArray, next: Int?, now: Int) {
            val target = next ?: 1441
            val cal = Calendar.getInstance().apply {
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
                add(Calendar.MINUTE, target - now)
            }
            val intent = Intent(context, OutageWidget::class.java).apply {
                action = AppWidgetManager.ACTION_APPWIDGET_UPDATE
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
            }
            val pi = PendingIntent.getBroadcast(
                context, 1, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.set(AlarmManager.RTC, cal.timeInMillis, pi)
        }

        private fun bar(intervals: List<IntArray>, now: Int): Bitmap {
            val w = 720
            val h = 64
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val c = Canvas(bmp)
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            c.clipPath(Path().apply {
                addRoundRect(RectF(0f, 0f, w.toFloat(), h.toFloat()), 14f, 14f, Path.Direction.CW)
            })
            p.color = 0xFFC8E6C9.toInt()
            c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
            p.color = 0xFFEF9A9A.toInt()
            for (iv in intervals) {
                if (iv[0] >= 1440) continue
                c.drawRect(iv[0] * w / 1440f, 0f, minOf(iv[1], 1440) * w / 1440f, h.toFloat(), p)
            }
            p.color = 0xFF202124.toInt()
            val x = now * w / 1440f
            c.drawRect(x - 3f, 0f, x + 3f, h.toFloat(), p)
            return bmp
        }
    }
}
