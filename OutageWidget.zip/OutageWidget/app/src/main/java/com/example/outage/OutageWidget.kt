package com.example.outage

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Build
import android.provider.AlarmClock
import android.widget.RemoteViews
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Calendar
import java.util.Locale

class OutageWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val pending = goAsync()
        Thread {
            try {
                if (!Sources.refreshIfStale(context)) Weather.refreshIfStale(context)
            } catch (e: Exception) {
                // малюємо з кешу
            }
            try {
                renderAll(context)
            } finally {
                pending.finish()
            }
        }.start()
    }

    override fun onDisabled(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(tickIntent(context, IntArray(0)))
    }

    companion object {
        private fun tickIntent(context: Context, ids: IntArray): PendingIntent {
            val i = Intent(context, OutageWidget::class.java).apply {
                action = AppWidgetManager.ACTION_APPWIDGET_UPDATE
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
            }
            return PendingIntent.getBroadcast(
                context, 1, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
        }

        private fun scheduleTick(context: Context, ids: IntArray) {
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val at = (System.currentTimeMillis() / 60_000L + 1) * 60_000L + 200L
            val pi = tickIntent(context, ids)
            try {
                if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC, at, pi)
                } else {
                    am.setAndAllowWhileIdle(AlarmManager.RTC, at, pi)
                }
            } catch (e: SecurityException) {
                am.set(AlarmManager.RTC, at, pi)
            }
        }

        fun renderAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, OutageWidget::class.java))
            if (ids.isEmpty()) return
            try {
                render(context, manager, ids)
            } finally {
                scheduleTick(context, ids)
            }
        }

        private fun render(context: Context, manager: AppWidgetManager, ids: IntArray) {
            val plan = Schedule.plan(context)
            val cal = Calendar.getInstance()
            val hour = cal.get(Calendar.HOUR_OF_DAY)
            val minute = cal.get(Calendar.MINUTE)
            val now = hour * 60 + minute

            val chip: String
            val kind: Int // 0 світло є, 1 світла немає, 2 можливе відключення
            val big: String
            val sub: String

            if (!plan.hasData) {
                chip = "Немає даних"; kind = 1; big = "—"
                sub = Schedule.error(context) ?: "Очікуємо графік"
            } else if (plan.emergency) {
                chip = "Аварійні"; kind = 1; big = "—"
                sub = "Графік тимчасово не діє"
            } else {
                val current = plan.intervals.firstOrNull { now >= it[0] && now < it[1] }
                val inMaybe = plan.maybe.firstOrNull { now >= it[0] && now < it[1] }
                if (current != null) {
                    chip = "Світла немає"; kind = 1
                    big = Schedule.dur(current[1] - now)
                    sub = "до увімкнення · о ${Schedule.fmt(current[1])}"
                } else if (inMaybe != null) {
                    chip = "Можливе відключення"; kind = 2
                    val nextDefinite = plan.intervals.firstOrNull { it[0] >= now }
                    if (nextDefinite != null) {
                        big = Schedule.dur(nextDefinite[0] - now)
                        sub = "до точного відключення · о ${Schedule.fmt(nextDefinite[0])}"
                    } else {
                        big = Schedule.dur(inMaybe[1] - now)
                        sub = "жовта година · до ${Schedule.fmt(inMaybe[1])}"
                    }
                } else {
                    chip = "Світло є"; kind = 0
                    val nextDefinite = plan.intervals.firstOrNull { it[0] > now }
                    val nextMaybe = plan.maybe.firstOrNull { it[0] > now }
                    if (nextMaybe != null && (nextDefinite == null || nextMaybe[0] < nextDefinite[0])) {
                        big = Schedule.dur(nextMaybe[0] - now)
                        sub = "до можливого відключення · о ${Schedule.fmt(nextMaybe[0])}"
                    } else if (nextDefinite != null) {
                        big = Schedule.dur(nextDefinite[0] - now)
                        sub = "до відключення · о ${Schedule.fmt(nextDefinite[0])}"
                    } else {
                        big = "Без відключень"
                        sub = "більше сьогодні немає"
                    }
                }
            }

            val today = Schedule.dayInfo(context, 0)
            val tomorrow = Schedule.dayInfo(context, 1)
            val tomorrowReady = tomorrow != null && tomorrow.status != "WaitingForSchedule"
            val tomorrowSlots = if (tomorrowReady) tomorrow!!.slots else emptyList()
            val tomorrowMaybe = if (tomorrowReady) tomorrow!!.maybe else emptyList()

            val todayText = when {
                today == null -> "Сьогодні: даних немає"
                today.slots.isEmpty() -> "Сьогодні: відключень немає"
                else -> "Сьогодні: " + Schedule.fmtList(today.slots)
            }
            val tomorrowText = when {
                !tomorrowReady -> "Завтра: графік ще не опубліковано"
                tomorrowSlots.isEmpty() -> "Завтра: відключень немає"
                else -> "Завтра: " + Schedule.fmtList(tomorrowSlots)
            }
            val anyMaybe = (today?.maybe?.isNotEmpty() == true) || tomorrowMaybe.isNotEmpty()
            val noteText = if (anyMaybe) "Жовтим: можливе відключення" else ""

            val w = Weather.cached(context)
            val wIcon: String
            val wTemp: String
            val wDesc: String
            if (w != null) {
                val d = Weather.describe(w.code)
                wIcon = d.first
                wTemp = Weather.fmtTemp(w.temp)
                wDesc = d.second + " · " + Weather.fmtTemp(w.min) + ".." + Weather.fmtTemp(w.max)
            } else {
                wIcon = ""; wTemp = "—"; wDesc = "Немає даних"
            }

            val dateText = LocalDate.now()
                .format(DateTimeFormatter.ofPattern("EEEE, d MMMM", Locale("uk", "UA")))
                .replaceFirstChar { it.uppercase() }

            val openApp = PendingIntent.getActivity(
                context, 0, Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val openAlarm = PendingIntent.getActivity(
                context, 2,
                Intent(AlarmClock.ACTION_SHOW_ALARMS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val fg = context.getColor(
                when (kind) {
                    0 -> R.color.on_fg
                    2 -> R.color.maybe_fg
                    else -> R.color.off_fg
                }
            )
            val pill = when (kind) {
                0 -> R.drawable.pill_on
                2 -> R.drawable.pill_maybe
                else -> R.drawable.pill_off
            }
            val clock = clockBitmap(context, hour, minute)
            val barToday = bar(context, today?.slots ?: emptyList(), today?.maybe ?: emptyList(), now, today == null)
            val barTomorrow = bar(context, tomorrowSlots, tomorrowMaybe, null, !tomorrowReady)
            val panelTitle = "Черга ${Schedule.group(context)} · ${Schedule.sourceLabel(context)}"

            for (id in ids) {
                val v = RemoteViews(context.packageName, R.layout.widget)
                v.setImageViewBitmap(R.id.clock, clock)
                v.setTextViewText(R.id.date, dateText)
                v.setTextViewText(R.id.w_icon, wIcon)
                v.setTextViewText(R.id.w_temp, wTemp)
                v.setTextViewText(R.id.w_desc, wDesc)
                v.setTextViewText(R.id.w_city, "📍 " + Weather.cityName(context))
                v.setTextViewText(R.id.title, panelTitle)
                v.setTextViewText(R.id.chip, chip)
                v.setInt(R.id.chip, "setBackgroundResource", pill)
                v.setTextColor(R.id.chip, fg)
                v.setTextViewText(R.id.big, big)
                v.setTextColor(R.id.big, fg)
                v.setTextViewText(R.id.sub, sub)
                v.setImageViewBitmap(R.id.bar_today, barToday)
                v.setImageViewBitmap(R.id.bar_tomorrow, barTomorrow)
                v.setTextViewText(R.id.list_today, todayText)
                v.setTextViewText(R.id.list_tomorrow, tomorrowText)
                v.setTextViewText(R.id.list_note, noteText)
                v.setOnClickPendingIntent(R.id.root, openApp)
                v.setOnClickPendingIntent(R.id.clock, openAlarm)
                manager.updateAppWidget(id, v)
            }
        }

        private fun clockBitmap(ctx: Context, h: Int, m: Int): Bitmap {
            val text = "%02d:%02d".format(h, m)
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = 168f
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            }
            val fm = p.fontMetrics
            val gap = -4f
            var width = 0f
            for (ch in text) width += p.measureText(ch.toString()) + gap
            val bmp = Bitmap.createBitmap(
                width.toInt() + 8, (fm.descent - fm.ascent).toInt() + 4, Bitmap.Config.ARGB_8888
            )
            val c = Canvas(bmp)
            var x = 4f
            var redDone = false
            for (ch in text) {
                if (ch == '1' && !redDone) {
                    p.color = ctx.getColor(R.color.clock_red)
                    redDone = true
                } else {
                    p.color = ctx.getColor(R.color.text_primary)
                }
                c.drawText(ch.toString(), x, -fm.ascent + 2f, p)
                x += p.measureText(ch.toString()) + gap
            }
            return bmp
        }

        private fun bar(
            ctx: Context, slots: List<IntArray>, maybe: List<IntArray>, nowMin: Int?, dim: Boolean
        ): Bitmap {
            val w = 900
            val h = 54
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val c = Canvas(bmp)
            val p = Paint(Paint.ANTI_ALIAS_FLAG)

            c.save()
            c.clipPath(Path().apply {
                addRoundRect(RectF(0f, 8f, w.toFloat(), 46f), 19f, 19f, Path.Direction.CW)
            })
            p.color = ctx.getColor(R.color.bar_on)
            if (dim) p.alpha = 90
            c.drawRect(0f, 8f, w.toFloat(), 46f, p)

            p.color = ctx.getColor(R.color.bar_maybe)
            for (iv in maybe) {
                if (iv[0] >= 1440) continue
                c.drawRect(iv[0] * w / 1440f, 8f, minOf(iv[1], 1440) * w / 1440f, 46f, p)
            }
            p.color = ctx.getColor(R.color.bar_off)
            for (iv in slots) {
                if (iv[0] >= 1440) continue
                c.drawRect(iv[0] * w / 1440f, 8f, minOf(iv[1], 1440) * w / 1440f, 46f, p)
            }
            c.restore()

            if (nowMin != null) {
                val x = (nowMin * w / 1440f).coerceIn(8f, w - 8f)
                p.color = ctx.getColor(R.color.marker_ring)
                c.drawRoundRect(RectF(x - 8f, 0f, x + 8f, h.toFloat()), 8f, 8f, p)
                p.color = ctx.getColor(R.color.marker)
                c.drawRoundRect(RectF(x - 4.5f, 3f, x + 4.5f, h - 3f), 4.5f, 4.5f, p)
            }
            return bmp
        }
    }
}
