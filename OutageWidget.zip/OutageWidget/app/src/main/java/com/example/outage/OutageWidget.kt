package com.example.outage

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.widget.RemoteViews
import java.util.Calendar

class OutageWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val pending = goAsync()
        Thread {
            try {
                Yasno.refresh(context)
                renderAll(context)
            } finally {
                pending.finish()
            }
        }.start()
    }

    companion object {
        fun renderAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, OutageWidget::class.java))
            if (ids.isNotEmpty()) render(context, manager, ids)
        }

        private fun render(context: Context, manager: AppWidgetManager, ids: IntArray) {
            val plan = Schedule.plan(context)
            val cal = Calendar.getInstance()
            val now = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)

            val chip: String
            val off: Boolean
            val big: String
            val sub: String
            var next: Int? = null

            if (!plan.hasData) {
                chip = "Немає даних"; off = true; big = "—"
                sub = Schedule.error(context) ?: "Очікуємо графік"
            } else if (plan.emergency) {
                chip = "Аварійні"; off = true; big = "—"
                sub = "Графік тимчасово не діє"
            } else {
                val current = plan.intervals.firstOrNull { now >= it[0] && now < it[1] }
                if (current != null) {
                    chip = "Світла немає"; off = true
                    big = Schedule.dur(current[1] - now)
                    sub = "до увімкнення · о ${Schedule.fmt(current[1])}"
                    next = current[1]
                } else {
                    chip = "Світло є"; off = false
                    val up = plan.intervals.firstOrNull { it[0] > now }
                    if (up != null) {
                        big = Schedule.dur(up[0] - now)
                        sub = "до відключення · о ${Schedule.fmt(up[0])}"
                        next = up[0]
                    } else {
                        big = "Без відключень"
                        sub = "більше сьогодні немає"
                    }
                }
            }

            var list = if (plan.hasData) Schedule.todayText(plan).ifEmpty { "Сьогодні без відключень" } else ""
            if (plan.waiting && plan.hasData) list += " · може змінитися"
            if (Schedule.error(context) != null && Schedule.fetchedAt(context) > 0) list += " · офлайн"

            val openApp = PendingIntent.getActivity(
                context, 0, Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val fg = context.getColor(if (off) R.color.off_fg else R.color.on_fg)
            val barBitmap = bar(context, plan.intervals, now)

            for (id in ids) {
                val v = RemoteViews(context.packageName, R.layout.widget)
                v.setTextViewText(R.id.title, "Кривий Ріг · ${Schedule.group(context)}")
                v.setTextViewText(R.id.chip, chip)
                v.setInt(R.id.chip, "setBackgroundResource", if (off) R.drawable.pill_off else R.drawable.pill_on)
                v.setTextColor(R.id.chip, fg)
                v.setTextViewText(R.id.big, big)
                v.setTextColor(R.id.big, fg)
                v.setTextViewText(R.id.sub, sub)
                v.setTextViewText(R.id.list, list)
                v.setImageViewBitmap(R.id.bar, barBitmap)
                v.setOnClickPendingIntent(R.id.root, openApp)
                manager.updateAppWidget(id, v)
            }
            scheduleNext(context, ids, next, now)
        }

        private fun scheduleNext(context: Context, ids: IntArray, next: Int?, now: Int) {
            val target = next ?: 1441
            val cal = Calendar.getInstance().apply {
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
                add(Calendar.MINUTE, target - now)
            }
            val intent = Intent(context, OutageWidget::class.java).apply {
                action = AppWidgetManager.ACTION_APPWIDGET_UPDATE
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
            }
            val pi = PendingIntent.getBroadcast(
                context, 1, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.set(AlarmManager.RTC, cal.timeInMillis, pi)
        }

        private fun bar(ctx: Context, intervals: List<IntArray>, now: Int): Bitmap {
            val w = 1008
            val h = 72
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val c = Canvas(bmp)
            val p = Paint(Paint.ANTI_ALIAS_FLAG)

            p.color = ctx.getColor(R.color.bar_on)
            c.drawRoundRect(RectF(0f, 14f, w.toFloat(), 58f), 22f, 22f, p)

            p.color = ctx.getColor(R.color.bar_off)
            for (iv in intervals) {
                if (iv[0] >= 1440) continue
                val l = iv[0] * w / 1440f
                val r = minOf(iv[1], 1440) * w / 1440f
                val rad = minOf(22f, (r - l) / 2f)
                c.drawRoundRect(RectF(l, 14f, r, 58f), rad, rad, p)
            }

            val x = (now * w / 1440f).coerceIn(9f, w - 9f)
            p.color = ctx.getColor(R.color.marker_ring)
            c.drawRoundRect(RectF(x - 9f, 2f, x + 9f, 70f), 9f, 9f, p)
            p.color = ctx.getColor(R.color.marker)
            c.drawRoundRect(RectF(x - 5f, 6f, x + 5f, 66f), 5f, 5f, p)
            return bmp
        }
    }
}
