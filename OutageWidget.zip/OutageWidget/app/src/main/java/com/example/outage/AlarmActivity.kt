package com.example.outage

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.AlarmClock
import android.widget.Toast

class AlarmActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!openClock()) {
            Toast.makeText(this, "Не вдалося відкрити застосунок «Годинник»", Toast.LENGTH_SHORT).show()
        }
        finish()
    }

    private fun openClock(): Boolean {
        try {
            startActivity(Intent(AlarmClock.ACTION_SHOW_ALARMS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return true
        } catch (e: Exception) {
            // пробуємо відкрити застосунок годинника напряму
        }
        val packages = listOf(
            "com.oneplus.deskclock",
            "com.oplus.alarmclock",
            "com.coloros.alarmclock",
            "com.google.android.deskclock",
            "com.android.deskclock"
        )
        for (pkg in packages) {
            val launch = packageManager.getLaunchIntentForPackage(pkg) ?: continue
            try {
                startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return true
            } catch (e: Exception) {
                // наступний варіант
            }
        }
        return false
    }
}
