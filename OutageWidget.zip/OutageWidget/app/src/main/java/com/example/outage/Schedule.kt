package com.example.outage

import android.content.Context
import org.json.JSONObject
import java.time.LocalDate

class Plan(
    val intervals: List<IntArray>,
    val emergency: Boolean,
    val waiting: Boolean,
    val hasData: Boolean
)

object Schedule {
    private fun p(ctx: Context) = ctx.getSharedPreferences("outage", Context.MODE_PRIVATE)

    fun group(ctx: Context): String = p(ctx).getString("group", "4.2") ?: "4.2"

    fun setGroup(ctx: Context, g: String) {
        p(ctx).edit().putString("group", g).remove("data").remove("error").apply()
    }

    fun saveData(ctx: Context, json: String, updatedOn: String) {
        p(ctx).edit().putString("data", json).putString("updated", updatedOn)
            .putLong("fetched", System.currentTimeMillis()).remove("error").apply()
    }

    fun setError(ctx: Context, msg: String) {
        p(ctx).edit().putString("error", msg).apply()
    }

    fun error(ctx: Context): String? = p(ctx).getString("error", null)
    fun fetchedAt(ctx: Context): Long = p(ctx).getLong("fetched", 0L)
    fun updatedOn(ctx: Context): String = p(ctx).getString("updated", "") ?: ""

    fun cachedIds(ctx: Context): Pair<Int, Int>? {
        val sp = p(ctx)
        return if (sp.contains("region_id")) sp.getInt("region_id", 0) to sp.getInt("dso_id", 0) else null
    }

    fun saveIds(ctx: Context, region: Int, dso: Int) {
        p(ctx).edit().putInt("region_id", region).putInt("dso_id", dso).apply()
    }

    fun plan(ctx: Context): Plan {
        val raw = p(ctx).getString("data", null) ?: return Plan(emptyList(), false, false, false)
        val days = JSONObject(raw).getJSONArray("days")
        val today = LocalDate.now()
        val wanted = listOf(today.toString() to 0, today.plusDays(1).toString() to 1440)
        val list = mutableListOf<IntArray>()
        var emergency = false
        var waiting = false
        var has = false
        for ((date, shift) in wanted) {
            for (i in 0 until days.length()) {
                val d = days.getJSONObject(i)
                if (d.optString("date") != date) continue
                if (shift == 0) {
                    has = true
                    emergency = d.optString("status") == "EmergencyShutdowns"
                    waiting = d.optString("status") == "WaitingForSchedule"
                }
                val s = d.getJSONArray("slots")
                for (j in 0 until s.length()) {
                    val a = s.getJSONArray(j)
                    list.add(intArrayOf(a.getInt(0) + shift, a.getInt(1) + shift))
                }
            }
        }
        list.sortBy { it[0] }
        val merged = mutableListOf<IntArray>()
        for (iv in list) {
            val last = merged.lastOrNull()
            if (last != null && iv[0] <= last[1]) last[1] = maxOf(last[1], iv[1])
            else merged.add(intArrayOf(iv[0], iv[1]))
        }
        return Plan(merged, emergency, waiting, has)
    }

    fun fmt(m: Int): String {
        if (m == 1440) return "24:00"
        val x = m % 1440
        return "%02d:%02d".format(x / 60, x % 60)
    }

    fun dur(m: Int): String {
        val h = m / 60
        val min = m % 60
        return if (h == 0) "$min хв" else if (min == 0) "$h год" else "$h год $min хв"
    }

    fun todayText(plan: Plan): String =
        plan.intervals.filter { it[0] < 1440 }.joinToString("   ") { fmt(it[0]) + "–" + fmt(it[1]) }
}
