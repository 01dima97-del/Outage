package com.example.outage

import android.content.Context
import org.json.JSONObject
import java.time.LocalDate

class Plan(
    val intervals: List<IntArray>,
    val maybe: List<IntArray>,
    val emergency: Boolean,
    val waiting: Boolean,
    val hasData: Boolean
)

class DayInfo(val status: String, val slots: List<IntArray>, val maybe: List<IntArray>)

object Schedule {
    private fun p(ctx: Context) = ctx.getSharedPreferences("outage", Context.MODE_PRIVATE)

    fun group(ctx: Context): String = p(ctx).getString("group", "4.2") ?: "4.2"
    fun source(ctx: Context): String = p(ctx).getString("source", "yasno") ?: "yasno"
    fun sourceLabel(ctx: Context): String = if (source(ctx) == "mykolaiv") "Миколаївобленерго" else "YASNO"
    fun regionId(ctx: Context): Int = p(ctx).getInt("region_id", 0)

    fun setSelection(ctx: Context, source: String, regionId: Int, dsoId: Int, regionName: String, group: String) {
        p(ctx).edit()
            .putString("source", source)
            .putInt("region_id", regionId)
            .putInt("dso_id", dsoId)
            .putString("region_name", regionName)
            .putString("group", group)
            .remove("data").remove("error").remove("fetched").remove("y_try")
            .apply()
    }

    fun saveData(ctx: Context, json: String, updatedOn: String) {
        p(ctx).edit().putString("data", json).putString("updated", updatedOn)
            .putLong("fetched", System.currentTimeMillis()).remove("error").apply()
    }

    fun setError(ctx: Context, msg: String) {
        p(ctx).edit().putString("error", msg).apply()
    }

    fun error(ctx: Context): String? = p(ctx).getString("error", null)
    fun fetchedAt(ctx: Context): Long = p(ctx).getLong("fetched", 0L)

    fun cachedIds(ctx: Context): Pair<Int, Int>? {
        val sp = p(ctx)
        val r = sp.getInt("region_id", 0)
        val d = sp.getInt("dso_id", 0)
        return if (r > 0 && d > 0) r to d else null
    }

    fun saveIds(ctx: Context, region: Int, dso: Int) {
        p(ctx).edit().putInt("region_id", region).putInt("dso_id", dso).apply()
    }

    fun getLong(ctx: Context, key: String): Long = p(ctx).getLong(key, 0L)

    fun putLong(ctx: Context, key: String, v: Long) {
        p(ctx).edit().putLong(key, v).apply()
    }

    private fun merge(list: MutableList<IntArray>): List<IntArray> {
        list.sortBy { it[0] }
        val merged = mutableListOf<IntArray>()
        for (iv in list) {
            val last = merged.lastOrNull()
            if (last != null && iv[0] <= last[1]) last[1] = maxOf(last[1], iv[1])
            else merged.add(intArrayOf(iv[0], iv[1]))
        }
        return merged
    }

    private fun readList(arr: org.json.JSONArray?, shift: Int, out: MutableList<IntArray>) {
        if (arr == null) return
        for (j in 0 until arr.length()) {
            val a = arr.getJSONArray(j)
            out.add(intArrayOf(a.getInt(0) + shift, a.getInt(1) + shift))
        }
    }

    fun plan(ctx: Context): Plan {
        val raw = p(ctx).getString("data", null) ?: return Plan(emptyList(), emptyList(), false, false, false)
        val days = JSONObject(raw).getJSONArray("days")
        val today = LocalDate.now()
        val wanted = listOf(today.toString() to 0, today.plusDays(1).toString() to 1440)
        val definite = mutableListOf<IntArray>()
        val maybe = mutableListOf<IntArray>()
        var emergency = false
        var waiting = false
        var has = false
        for ((date, shift) in wanted) {
            for (i in 0 until days.length()) {
                val d = days.getJSONObject(i)
                if (d.optString("date") != date) continue
                if (shift == 0) {
                    has = true
                    emergency = d.optString("status") == "EmergencyShutdowns"
                    waiting = d.optString("status") == "WaitingForSchedule"
                }
                readList(d.optJSONArray("slots"), shift, definite)
                readList(d.optJSONArray("maybe"), shift, maybe)
            }
        }
        return Plan(merge(definite), merge(maybe), emergency, waiting, has)
    }

    fun dayInfo(ctx: Context, offset: Long): DayInfo? {
        val raw = p(ctx).getString("data", null) ?: return null
        val date = LocalDate.now().plusDays(offset).toString()
        val days = JSONObject(raw).getJSONArray("days")
        for (i in 0 until days.length()) {
            val d = days.getJSONObject(i)
            if (d.optString("date") != date) continue
            val slots = mutableListOf<IntArray>()
            val maybe = mutableListOf<IntArray>()
            readList(d.optJSONArray("slots"), 0, slots)
            readList(d.optJSONArray("maybe"), 0, maybe)
            slots.sortBy { it[0] }
            maybe.sortBy { it[0] }
            return DayInfo(d.optString("status"), slots, maybe)
        }
        return null
    }

    fun fmt(m: Int): String {
        if (m == 1440) return "24:00"
        val x = m % 1440
        return "%02d:%02d".format(x / 60, x % 60)
    }

    fun dur(m: Int): String {
        val h = m / 60
        val min = m % 60
        return if (h == 0) "$min хв" else if (min == 0) "$h год" else "$h год $min хв"
    }

    fun fmtList(slots: List<IntArray>): String =
        slots.joinToString(" · ") { fmt(it[0]) + "–" + fmt(it[1]) }

    fun todayText(plan: Plan): String =
        plan.intervals.filter { it[0] < 1440 }.joinToString("   ") { fmt(it[0]) + "–" + fmt(it[1]) }
}
