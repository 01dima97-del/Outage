package com.example.outage

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class Region(val name: String, val regionId: Int, val dsoId: Int)

object Yasno {
    private const val BASE = "https://app.yasno.ua/api/blackout-service/public/shutdowns"

    internal fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 5000
        c.readTimeout = 5000
        c.setRequestProperty("Accept", "application/json")
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) OutageWidget")
        try {
            if (c.responseCode !in 200..299) error("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().readText()
        } finally {
            c.disconnect()
        }
    }

    private fun fallbackRegions(): List<Region> = listOf(Region("Дніпро", 3, 301), Region("Київ", 25, 902))

    fun regions(ctx: Context): List<Region> {
        val raw = ctx.getSharedPreferences("outage", Context.MODE_PRIVATE).getString("regions_json", null)
        if (raw != null) {
            try {
                val arr = JSONArray(raw)
                val list = mutableListOf<Region>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    list.add(Region(o.getString("n"), o.getInt("r"), o.getInt("d")))
                }
                if (list.isNotEmpty()) return list
            } catch (e: Exception) {
                // використовуємо запасний список
            }
        }
        return fallbackRegions()
    }

    fun refreshRegions(ctx: Context): Boolean {
        try {
            val txt = get("$BASE/addresses/v2/regions").trim()
            val arr = if (txt.startsWith("[")) JSONArray(txt)
            else JSONObject(txt).optJSONArray("regions") ?: JSONArray()
            val out = JSONArray()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val name = o.optString("value", o.optString("name", ""))
                val dsos = o.optJSONArray("dsos")
                if (name.isNotEmpty() && dsos != null && dsos.length() > 0) {
                    out.put(
                        JSONObject().put("n", name).put("r", o.getInt("id"))
                            .put("d", dsos.getJSONObject(0).getInt("id"))
                    )
                }
            }
            if (out.length() == 0) return false
            ctx.getSharedPreferences("outage", Context.MODE_PRIVATE).edit()
                .putString("regions_json", out.toString()).apply()
            return true
        } catch (e: Exception) {
            return false
        }
    }

    private fun ids(ctx: Context): Pair<Int, Int> {
        Schedule.cachedIds(ctx)?.let { return it }
        var list = regions(ctx)
        if (ctx.getSharedPreferences("outage", Context.MODE_PRIVATE).getString("regions_json", null) == null) {
            if (refreshRegions(ctx)) list = regions(ctx)
        }
        val r = list.firstOrNull { it.name.contains("Дніпро", ignoreCase = true) } ?: list.first()
        Schedule.saveIds(ctx, r.regionId, r.dsoId)
        return r.regionId to r.dsoId
    }

    fun refresh(ctx: Context) {
        try {
            val (region, dso) = ids(ctx)
            val root = JSONObject(get("$BASE/regions/$region/dsos/$dso/planned-outages"))
            val g = Schedule.group(ctx)
            val grp = root.optJSONObject(g) ?: error("Черги $g немає у відповіді сервера")
            val days = JSONArray()
            for (key in listOf("today", "tomorrow")) {
                val d = grp.optJSONObject(key) ?: continue
                val slots = JSONArray()
                val arr = d.optJSONArray("slots") ?: JSONArray()
                for (i in 0 until arr.length()) {
                    val s = arr.getJSONObject(i)
                    if (s.optString("type") == "Definite") {
                        slots.put(JSONArray().put(s.getInt("start")).put(s.getInt("end")))
                    }
                }
                days.put(
                    JSONObject().put("date", d.optString("date").take(10))
                        .put("status", d.optString("status")).put("slots", slots)
                        .put("maybe", JSONArray())
                )
            }
            Schedule.saveData(ctx, JSONObject().put("days", days).toString(), grp.optString("updatedOn"))
        } catch (e: Exception) {
            Schedule.setError(ctx, e.message ?: e.javaClass.simpleName)
        }
    }
}
