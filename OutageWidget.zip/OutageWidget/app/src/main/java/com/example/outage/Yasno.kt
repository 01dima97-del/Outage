package com.example.outage

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Yasno {
    private const val BASE = "https://app.yasno.ua/api/blackout-service/public/shutdowns"

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 5000
        c.readTimeout = 5000
        c.setRequestProperty("Accept", "application/json")
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) OutageWidget")
        try {
            if (c.responseCode !in 200..299) error("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().readText()
        } finally {
            c.disconnect()
        }
    }

    private fun ids(ctx: Context): Pair<Int, Int> {
        Schedule.cachedIds(ctx)?.let { return it }
        try {
            val txt = get("$BASE/addresses/v2/regions").trim()
            val arr = if (txt.startsWith("[")) JSONArray(txt)
            else JSONObject(txt).optJSONArray("regions") ?: JSONArray()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val name = o.optString("value", o.optString("name", ""))
                val dsos = o.optJSONArray("dsos")
                if (name.contains("Дніпро", ignoreCase = true) && dsos != null && dsos.length() > 0) {
                    val r = o.getInt("id")
                    val d = dsos.getJSONObject(0).getInt("id")
                    Schedule.saveIds(ctx, r, d)
                    return r to d
                }
            }
        } catch (e: Exception) {
            // нижче використовуємо запасні значення
        }
        return 3 to 301
    }

    fun refresh(ctx: Context) {
        try {
            val (region, dso) = ids(ctx)
            val root = JSONObject(get("$BASE/regions/$region/dsos/$dso/planned-outages"))
            val g = Schedule.group(ctx)
            val grp = root.optJSONObject(g) ?: error("Черги $g немає у відповіді сервера")
            val days = JSONArray()
            for (key in listOf("today", "tomorrow")) {
                val d = grp.optJSONObject(key) ?: continue
                val slots = JSONArray()
                val arr = d.optJSONArray("slots") ?: JSONArray()
                for (i in 0 until arr.length()) {
                    val s = arr.getJSONObject(i)
                    if (s.optString("type") == "Definite") {
                        slots.put(JSONArray().put(s.getInt("start")).put(s.getInt("end")))
                    }
                }
                days.put(
                    JSONObject().put("date", d.optString("date").take(10))
                        .put("status", d.optString("status")).put("slots", slots)
                )
            }
            Schedule.saveData(ctx, JSONObject().put("days", days).toString(), grp.optString("updatedOn"))
        } catch (e: Exception) {
            Schedule.setError(ctx, e.message ?: e.javaClass.simpleName)
        }
    }
}
