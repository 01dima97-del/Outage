package com.example.outage

import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Calendar

class MainActivity : Activity() {
    private lateinit var intervalsView: TextView
    private lateinit var metaView: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val textPrimary = getColor(R.color.text_primary)
        val textSecondary = getColor(R.color.text_secondary)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(56), dp(20), dp(24))
        }

        val title = TextView(this).apply {
            text = "Графік світла"
            textSize = 28f
            setTextColor(textPrimary)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        val subtitle = TextView(this).apply {
            text = "Кривий Ріг · дані YASNO оновлюються автоматично"
            textSize = 14f
            setTextColor(textSecondary)
            setPadding(0, dp(4), 0, dp(20))
        }

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(getColor(R.color.card_bg), 24)
            setPadding(dp(20), dp(18), dp(20), dp(18))
        }
        val cardLabel = TextView(this).apply {
            text = "Сьогодні без світла"
            textSize = 13f
            setTextColor(textSecondary)
        }
        intervalsView = TextView(this).apply {
            textSize = 20f
            setTextColor(textPrimary)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, dp(6), 0, dp(6))
        }
        metaView = TextView(this).apply {
            textSize = 13f
            setTextColor(textSecondary)
        }
        listOf(cardLabel, intervalsView, metaView).forEach { card.addView(it) }

        val label = TextView(this).apply {
            text = "Черга"
            textSize = 13f
            setTextColor(textSecondary)
            setPadding(dp(4), dp(24), 0, dp(6))
        }
        val input = EditText(this).apply {
            setText(Schedule.group(this@MainActivity))
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT
            textSize = 18f
            setTextColor(textPrimary)
            background = rounded(getColor(R.color.card_bg), 16)
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        val hint = TextView(this).apply {
            text = "Формат 4.2, від 1.1 до 6.2"
            textSize = 12f
            setTextColor(textSecondary)
            setPadding(dp(4), dp(6), 0, 0)
        }

        val btn = Button(this).apply {
            text = "Зберегти й оновити"
            isAllCaps = false
            textSize = 16f
            setTextColor(Color.WHITE)
            background = rounded(getColor(R.color.accent), 26)
            stateListAnimator = null
            setOnClickListener {
                val g = input.text.toString().trim()
                if (!Regex("""[1-6]\.[12]""").matches(g)) {
                    metaView.text = "Вкажіть чергу у форматі 4.2"
                    return@setOnClickListener
                }
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                    .hideSoftInputFromWindow(input.windowToken, 0)
                if (g != Schedule.group(this@MainActivity)) Schedule.setGroup(this@MainActivity, g)
                metaView.text = "Завантажуємо…"
                Thread {
                    Yasno.refresh(this@MainActivity)
                    OutageWidget.renderAll(this@MainActivity)
                    runOnUiThread { showInfo() }
                }.start()
            }
        }
        val btnParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(52)
        ).apply { topMargin = dp(20) }

        val note = TextView(this).apply {
            text = "Додайте віджет: довге натискання на порожнє місце головного екрана → Віджети → Графік світла."
            textSize = 13f
            setTextColor(textSecondary)
            gravity = Gravity.START
            setPadding(dp(4), dp(24), 0, 0)
        }

        root.addView(title)
        root.addView(subtitle)
        root.addView(card)
        root.addView(label)
        root.addView(input)
        root.addView(hint)
        root.addView(btn, btnParams)
        root.addView(note)

        setContentView(ScrollView(this).apply { addView(root) })
        showInfo()
    }

    private fun showInfo() {
        val plan = Schedule.plan(this)
        intervalsView.text = if (plan.hasData)
            Schedule.todayText(plan).ifEmpty { "відключень немає" }
        else "даних ще немає"

        val sb = StringBuilder()
        val f = Schedule.fetchedAt(this)
        if (f > 0) {
            val t = Calendar.getInstance().apply { timeInMillis = f }
            sb.append("Оновлено о %02d:%02d".format(t.get(Calendar.HOUR_OF_DAY), t.get(Calendar.MINUTE)))
        }
        Schedule.error(this)?.let {
            if (sb.isNotEmpty()) sb.append("\n")
            sb.append("Помилка: ").append(it)
        }
        metaView.text = sb.toString()
    }
}
