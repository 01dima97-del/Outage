package com.example.outage

import android.app.Activity
import android.os.Bundle
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Calendar

class MainActivity : Activity() {
    private lateinit var info: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        val title = TextView(this).apply { text = "Графік відключень · Кривий Ріг"; textSize = 20f }
        val hint = TextView(this).apply {
            text = "Номер черги (наприклад 4.2). Дані автоматично беруться з YASNO (ДТЕК Дніпровські електромережі)."
            textSize = 14f
            setPadding(0, pad / 2, 0, pad / 2)
        }
        val input = EditText(this).apply {
            setText(Schedule.group(this@MainActivity))
            setSingleLine()
        }
        info = TextView(this).apply { textSize = 14f; setPadding(0, pad, 0, pad) }
        val btn = Button(this).apply {
            text = "Зберегти й оновити"
            setOnClickListener {
                val g = input.text.toString().trim()
                if (!Regex("""[1-6]\.[12]""").matches(g)) {
                    info.text = "Вкажіть чергу у форматі 4.2 (від 1.1 до 6.2)"
                    return@setOnClickListener
                }
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(input.windowToken, 0)
                if (g != Schedule.group(this@MainActivity)) Schedule.setGroup(this@MainActivity, g)
                info.text = "Завантажуємо…"
                Thread {
                    Yasno.refresh(this@MainActivity)
                    OutageWidget.renderAll(this@MainActivity)
                    runOnUiThread { showInfo() }
                }.start()
            }
        }
        val note = TextView(this).apply {
            text = "Щоб додати віджет: довге натискання на порожнє місце головного екрана → Віджети → Графік світла."
            textSize = 13f
            setPadding(0, pad, 0, 0)
        }
        listOf(title, hint, input, btn, info, note).forEach { root.addView(it) }
        setContentView(root)
        showInfo()
    }

    private fun showInfo() {
        val plan = Schedule.plan(this)
        val sb = StringBuilder()
        if (plan.hasData) {
            sb.append("Сьогодні без світла:\n").append(Schedule.todayText(plan).ifEmpty { "відключень немає" })
        } else sb.append("Даних ще немає")
        val f = Schedule.fetchedAt(this)
        if (f > 0) {
            val t = Calendar.getInstance().apply { timeInMillis = f }
            sb.append("\n\nОновлено: %02d:%02d".format(t.get(Calendar.HOUR_OF_DAY), t.get(Calendar.MINUTE)))
        }
        Schedule.error(this)?.let { sb.append("\nПомилка: ").append(it) }
        info.text = sb.toString()
    }
}
