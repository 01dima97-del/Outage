package com.example.outage

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.AlertDialog
import android.appwidget.AppWidgetManager
import android.content.pm.PackageManager
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.util.Calendar

class RegionItem(val label: String, val source: String, val regionId: Int, val dsoId: Int)

class MainActivity : Activity() {
    private lateinit var intervalsView: TextView
    private lateinit var metaView: TextView
    private lateinit var locView: TextView
    private lateinit var regionSpinner: Spinner
    private lateinit var queueSpinner: Spinner
    private lateinit var exactRow: LinearLayout
    private var regionItems: List<RegionItem> = emptyList()
    private val queues = (1..6).flatMap { listOf("$it.1", "$it.2") }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun buildRegionItems(): List<RegionItem> {
        val list = Yasno.regions(this)
            .map { RegionItem(it.name + " · YASNO", "yasno", it.regionId, it.dsoId) }
            .toMutableList()
        list.add(RegionItem("Миколаївська обл. · Миколаївобленерго", "mykolaiv", 0, 0))
        return list
    }

    private fun selectedIndex(items: List<RegionItem>): Int {
        val src = Schedule.source(this)
        val rid = Schedule.regionId(this)
        if (src == "mykolaiv") return items.indexOfFirst { it.source == "mykolaiv" }.coerceAtLeast(0)
        val byId = items.indexOfFirst { it.source == "yasno" && it.regionId == rid }
        if (byId >= 0) return byId
        return items.indexOfFirst { it.source == "yasno" && it.label.contains("Дніпро", ignoreCase = true) }
            .coerceAtLeast(0)
    }

    private fun fillRegions(keepLabel: String?) {
        regionItems = buildRegionItems()
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, regionItems.map { it.label })
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        regionSpinner.adapter = adapter
        val idx = if (keepLabel != null) regionItems.indexOfFirst { it.label == keepLabel } else -1
        regionSpinner.setSelection(if (idx >= 0) idx else selectedIndex(regionItems))
    }

    private fun spinnerBox(caption: String, spinner: Spinner): LinearLayout {
        spinner.setBackgroundColor(Color.TRANSPARENT)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(getColor(R.color.card_bg), 16)
            setPadding(dp(16), dp(10), dp(12), dp(6))
        }
        box.addView(TextView(this).apply {
            text = caption
            textSize = 12f
            setTextColor(getColor(R.color.text_secondary))
        })
        box.addView(spinner)
        return box
    }

    private fun sectionTitle(text: String) = TextView(this).apply {
        this.text = text
        textSize = 12f
        setTextColor(getColor(R.color.text_secondary))
        setPadding(dp(4), dp(20), 0, dp(6))
    }

    private fun smallButton(text: String, onClick: () -> Unit): Button = Button(this).apply {
        this.text = text
        isAllCaps = false
        textSize = 14f
        setTextColor(getColor(R.color.text_primary))
        background = rounded(getColor(R.color.card_bg), 14)
        stateListAnimator = null
        setOnClickListener { onClick() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val textPrimary = getColor(R.color.text_primary)
        val textSecondary = getColor(R.color.text_secondary)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(56), dp(20), dp(24))
        }

        root.addView(TextView(this).apply {
            text = "Графік світла"
            textSize = 28f
            setTextColor(textPrimary)
            setTypeface(typeface, Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "Дані оновлюються автоматично"
            textSize = 14f
            setTextColor(textSecondary)
            setPadding(0, dp(4), 0, dp(16))
        })

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(getColor(R.color.card_bg), 24)
            setPadding(dp(20), dp(18), dp(20), dp(18))
        }
        card.addView(TextView(this).apply {
            text = "Сьогодні без світла"
            textSize = 13f
            setTextColor(textSecondary)
        })
        intervalsView = TextView(this).apply {
            textSize = 18f
            setTextColor(textPrimary)
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(6), 0, dp(6))
        }
        metaView = TextView(this).apply {
            textSize = 13f
            setTextColor(textSecondary)
        }
        card.addView(intervalsView)
        card.addView(metaView)
        root.addView(card)

        root.addView(sectionTitle("Графіки світла"))
        regionSpinner = Spinner(this)
        queueSpinner = Spinner(this)
        fillRegions(null)
        val qAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, queues)
        qAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        queueSpinner.adapter = qAdapter
        queueSpinner.setSelection(queues.indexOf(Schedule.group(this)).coerceAtLeast(0))
        root.addView(spinnerBox("Регіон", regionSpinner))
        root.addView(spinnerBox("Черга", queueSpinner), LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(8) })
        root.addView(TextView(this).apply {
            text = "У списку регіони YASNO та Миколаївська область (Миколаївобленерго)."
            textSize = 11f
            setTextColor(textSecondary)
            setPadding(dp(4), dp(6), 0, 0)
        })

        root.addView(sectionTitle("Погода"))
        locView = TextView(this).apply {
            textSize = 16f
            setTextColor(textPrimary)
            background = rounded(getColor(R.color.card_bg), 16)
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        root.addView(locView)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val rowParams = { start: Int ->
            LinearLayout.LayoutParams(0, dp(46), 1f).apply { topMargin = dp(8); marginStart = start }
        }
        row.addView(smallButton("Визначити місце") { onLocateClick() }, rowParams(0))
        row.addView(smallButton("Обрати місто") { chooseCity() }, rowParams(dp(8)))
        root.addView(row)
        root.addView(TextView(this).apply {
            text = "Дозвіл на геолокацію лише під час використання. Місце оновлюється, коли ви відкриваєте застосунок."
            textSize = 11f
            setTextColor(textSecondary)
            setPadding(dp(4), dp(6), 0, 0)
        })

        root.addView(sectionTitle("Компактний віджет"))
        root.addView(smallButton("Додати компактний віджет на екран") { pinCompactWidget() },
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(46)))
        root.addView(TextView(this).apply {
            text = "Маленький віджет (від 4×1) тільки з плашкою черги, станом світла й короткими інтервалами відключень."
            textSize = 11f
            setTextColor(textSecondary)
            setPadding(dp(4), dp(6), 0, 0)
        })

        root.addView(sectionTitle("Сповіщення"))
        val notifRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(getColor(R.color.card_bg), 16)
            setPadding(dp(16), dp(10), dp(12), dp(10))
        }
        notifRow.addView(TextView(this).apply {
            text = "Сповіщати про зміну графіка"
            textSize = 16f
            setTextColor(textPrimary)
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        notifRow.addView(Switch(this).apply {
            isChecked = Notifier.enabled(this@MainActivity)
            setOnCheckedChangeListener { _, on ->
                Notifier.setEnabled(this@MainActivity, on)
                if (on) askNotifPermission()
            }
        })
        root.addView(notifRow)
        root.addView(TextView(this).apply {
            text = "Сповіщення приходить, коли графік на сьогодні змінюється або з'являється графік на завтра."
            textSize = 11f
            setTextColor(textSecondary)
            setPadding(dp(4), dp(6), 0, 0)
        })
        root.addView(smallButton("Перевірити звук сповіщення") { testNotification() },
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(46)).apply { topMargin = dp(8) })

        exactRow = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(getColor(R.color.card_bg), 16)
            setPadding(dp(16), dp(14), dp(16), dp(14))
            visibility = View.GONE
        }
        exactRow.addView(TextView(this).apply {
            text = "Щоб годинник на віджеті не відставав, дозвольте застосунку точні будильники."
            textSize = 13f
            setTextColor(textPrimary)
        })
        exactRow.addView(smallButton("Дозволити") { openExactAlarmSettings() }, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(44)
        ).apply { topMargin = dp(8) })
        root.addView(sectionTitle("Точність годинника"))
        root.addView(exactRow)

        val save = Button(this).apply {
            text = "Зберегти й оновити"
            isAllCaps = false
            textSize = 16f
            setTextColor(Color.WHITE)
            background = rounded(getColor(R.color.accent), 26)
            stateListAnimator = null
            setOnClickListener { onSave() }
        }
        root.addView(save, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(52)
        ).apply { topMargin = dp(22) })

        root.addView(TextView(this).apply {
            text = "Додайте віджет: довге натискання на порожнє місце головного екрана → Віджети → Графік світла. Натискання на годинник відкриває будильник."
            textSize = 13f
            setTextColor(textSecondary)
            gravity = Gravity.START
            setPadding(dp(4), dp(20), 0, 0)
        })

        setContentView(ScrollView(this).apply { addView(root) })
        showInfo()

        Notifier.ensureChannel(this)
        if (Notifier.enabled(this) && !Notifier.askedBefore(this)) {
            Notifier.markAsked(this)
            askNotifPermission()
        }

        Thread {
            if (Yasno.refreshRegions(this@MainActivity)) {
                runOnUiThread {
                    val keep = regionItems.getOrNull(regionSpinner.selectedItemPosition)?.label
                    fillRegions(keep)
                }
            }
        }.start()
    }

    private fun askNotifPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 8)
        }
    }

    private fun onSave() {
        val item = regionItems.getOrNull(regionSpinner.selectedItemPosition) ?: return
        val group = queues[queueSpinner.selectedItemPosition]
        val changed = item.source != Schedule.source(this) ||
            (item.source == "yasno" && item.regionId != Schedule.regionId(this)) ||
            group != Schedule.group(this)
        if (changed) Schedule.setSelection(this, item.source, item.regionId, item.dsoId, item.label, group)
        metaView.text = "Завантажуємо…"
        Thread {
            Sources.refresh(this@MainActivity)
            Weather.refresh(this@MainActivity)
            OutageWidget.renderAll(this@MainActivity)
            runOnUiThread { showInfo() }
        }.start()
    }

    private fun pinCompactWidget() {
        val manual = "Додайте вручну: довге натискання на екран → Віджети → Графік світла (компактний)"
        try {
            val mgr = AppWidgetManager.getInstance(this)
            if (Build.VERSION.SDK_INT >= 26 && mgr.isRequestPinAppWidgetSupported) {
                mgr.requestPinAppWidget(ComponentName(this, OutageCompactWidget::class.java), null, null)
            } else {
                Toast.makeText(this, manual, Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, manual, Toast.LENGTH_LONG).show()
        }
    }

    private fun testNotification() {
        Notifier.ensureChannel(this)
        val sent = Notifier.postTest(this)
        if (!sent) {
            Toast.makeText(this, "Дозвольте сповіщення для застосунку в налаштуваннях системи", Toast.LENGTH_LONG).show()
        }
    }

    private fun exactAlarmsAllowed(): Boolean {
        val am = getSystemService(ALARM_SERVICE) as AlarmManager
        return Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
    }

    private fun updateExactRow() {
        exactRow.visibility = if (exactAlarmsAllowed()) View.GONE else View.VISIBLE
    }

    private fun openExactAlarmSettings() {
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                startActivity(
                    Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))
                )
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Відкрийте налаштування застосунку й дозвольте точні будильники", Toast.LENGTH_LONG).show()
        }
    }

    override fun onResume() {
        super.onResume()
        if (::exactRow.isInitialized) updateExactRow()
    }

    private fun onLocateClick() {
        val fine = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (fine || coarse) locate()
        else requestPermissions(
            arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION), 7
        )
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 7) {
            if (grantResults.any { it == PackageManager.PERMISSION_GRANTED }) locate()
            else locView.text = "Немає дозволу на геолокацію. Можна обрати місто вручну."
        }
    }

    @Suppress("DEPRECATION")
    private fun locate() {
        locView.text = "Визначаємо місце…"
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        var best: Location? = null
        for (p in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)) {
            try {
                val l = lm.getLastKnownLocation(p)
                if (l != null && (best == null || l.time > best.time)) best = l
            } catch (e: Exception) {
                // пропускаємо джерело
            }
        }
        if (best != null) {
            onLocation(best)
            return
        }
        val provider = when {
            lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
            lm.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
            else -> null
        }
        if (provider == null) {
            locView.text = "Увімкніть геолокацію на телефоні або оберіть місто вручну."
            return
        }
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                lm.getCurrentLocation(provider, null, mainExecutor, java.util.function.Consumer<Location> { loc ->
                    if (loc != null) {
                        onLocation(loc)
                    } else {
                        locView.text = "Не вдалося визначити місце. Спробуйте ще раз."
                    }
                })
            } else {
                lm.requestSingleUpdate(provider, object : LocationListener {
                    override fun onLocationChanged(location: Location) { onLocation(location) }
                    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
                    override fun onProviderEnabled(provider: String) {}
                    override fun onProviderDisabled(provider: String) {}
                }, Looper.getMainLooper())
            }
        } catch (e: Exception) {
            locView.text = "Не вдалося визначити місце."
        }
    }

    private fun onLocation(loc: Location) {
        Thread {
            val city = Weather.reverseName(this@MainActivity, loc.latitude, loc.longitude)
            Weather.saveLocation(this@MainActivity, loc.latitude, loc.longitude, city, "gps")
            Weather.refresh(this@MainActivity)
            OutageWidget.renderAll(this@MainActivity)
            runOnUiThread { showInfo() }
        }.start()
    }

    private fun chooseCity() {
        val input = EditText(this).apply {
            hint = "Назва міста"
            setSingleLine()
        }
        val box = FrameLayout(this).apply {
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(input)
        }
        AlertDialog.Builder(this)
            .setTitle("Обрати місто")
            .setView(box)
            .setPositiveButton("Знайти") { _, _ -> searchCity(input.text.toString().trim()) }
            .setNegativeButton("Скасувати", null)
            .show()
    }

    private fun searchCity(q: String) {
        if (q.length < 2) return
        locView.text = "Шукаємо…"
        Thread {
            val res = try { Weather.search(q) } catch (e: Exception) { emptyList() }
            runOnUiThread {
                if (res.isEmpty()) {
                    locView.text = "Нічого не знайдено"
                } else {
                    val labels = res.map { it.label() }.toTypedArray()
                    AlertDialog.Builder(this)
                        .setTitle("Оберіть місто")
                        .setItems(labels) { _, i -> applyCity(res[i]) }
                        .show()
                    showInfo()
                }
            }
        }.start()
    }

    private fun applyCity(c: City) {
        Weather.saveLocation(this, c.lat, c.lon, c.name, "manual")
        Thread {
            Weather.refresh(this@MainActivity)
            OutageWidget.renderAll(this@MainActivity)
            runOnUiThread { showInfo() }
        }.start()
    }

    private fun showInfo() {
        val plan = Schedule.plan(this)
        intervalsView.text = if (plan.hasData)
            Schedule.todayText(plan).ifEmpty { "відключень немає" }
        else "даних ще немає"

        val sb = StringBuilder()
        val f = Schedule.fetchedAt(this)
        if (f > 0) {
            val t = Calendar.getInstance().apply { timeInMillis = f }
            sb.append("Оновлено о %02d:%02d".format(t.get(Calendar.HOUR_OF_DAY), t.get(Calendar.MINUTE)))
        }
        Schedule.error(this)?.let {
            if (sb.isNotEmpty()) sb.append("\n")
            sb.append("Помилка: ").append(it)
        }
        metaView.text = sb.toString()

        val how = when (Weather.mode(this)) {
            "gps" -> "за GPS"
            "manual" -> "обрано вручну"
            else -> "за замовчуванням"
        }
        locView.text = "📍 ${Weather.cityName(this)} · $how"
    }
}
